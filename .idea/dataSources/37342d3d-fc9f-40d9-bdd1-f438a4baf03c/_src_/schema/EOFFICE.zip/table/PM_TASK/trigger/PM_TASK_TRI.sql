create trigger PM_TASK_TRI
	before insert
	on PM_TASK
	for each row
begin  
   if inserting then 
      if :NEW."ID_TASK" is null then 
         select PM_TASK_SEQ.nextval into :NEW."ID_TASK" from dual; 
      end if; 
   end if; 
end;
