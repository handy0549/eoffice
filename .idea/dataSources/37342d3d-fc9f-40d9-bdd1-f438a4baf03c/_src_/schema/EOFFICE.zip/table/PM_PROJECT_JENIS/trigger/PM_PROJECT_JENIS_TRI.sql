create trigger PM_PROJECT_JENIS_TRI
	before insert
	on PM_PROJECT_JENIS
	for each row
begin  
   if inserting then 
      if :NEW."ID_PROJECT_JENIS" is null then 
         select PM_PROJECT_JENIS_SEQ.nextval into :NEW."ID_PROJECT_JENIS" from dual; 
      end if; 
   end if; 
end;
