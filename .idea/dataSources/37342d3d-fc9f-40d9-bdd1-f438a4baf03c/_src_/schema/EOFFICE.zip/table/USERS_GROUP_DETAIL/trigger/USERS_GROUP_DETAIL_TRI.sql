create trigger USERS_GROUP_DETAIL_TRI
	before insert
	on USERS_GROUP_DETAIL
	for each row
begin  
   if inserting then 
      if :NEW."ID_GROUP_DETAIL" is null then 
         select USERS_GROUP_DETAIL_SEQ.nextval into :NEW."ID_GROUP_DETAIL" from dual; 
      end if; 
   end if; 
end;
