create trigger PM_PROJECT_TRI
	before insert
	on PM_PROJECT
	for each row
begin  
   if inserting then 
      if :NEW."ID_PROJECT" is null then 
         select PM_PROJECT_SEQ.nextval into :NEW."ID_PROJECT" from dual; 
      end if; 
   end if; 
end;
