create trigger USERS_AKSES
	before insert
	on USERS_AKSES
	for each row
begin  
   if inserting then 
      if :NEW."ID_AKSES" is null then 
         select USERS_AKSES_SEQ.nextval into :NEW."ID_AKSES" from dual; 
      end if; 
   end if; 
end;
