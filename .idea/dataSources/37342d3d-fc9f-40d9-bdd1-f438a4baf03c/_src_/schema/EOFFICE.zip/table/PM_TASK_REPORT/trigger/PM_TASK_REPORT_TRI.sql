create trigger PM_TASK_REPORT_TRI
	before insert
	on PM_TASK_REPORT
	for each row
begin  
   if inserting then 
      if :NEW."ID_TASK_REPORT" is null then 
         select PM_TASK_REPORT_SEQ.nextval into :NEW."ID_TASK_REPORT" from dual; 
      end if; 
   end if; 
end;
