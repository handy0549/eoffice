create trigger PM_TASK_TEAM_TRI
	before insert
	on PM_TASK_TEAM
	for each row
begin  
   if inserting then 
      if :NEW."ID_TASK_TEAM" is null then 
         select PM_TASK_TEAM_SEQ.nextval into :NEW."ID_TASK_TEAM" from dual; 
      end if; 
   end if; 
end;
