create trigger OM_MODUL_TRI
	before insert
	on PM_MODUL
	for each row
begin  
   if inserting then 
      if :NEW."ID_MODUL" is null then 
         select PM_MODUL_SEQ.nextval into :NEW."ID_MODUL" from dual; 
      end if; 
   end if; 
end;
