create trigger M_PERUSAHAAN_IZIN_TRI
	before insert
	on PM_PERUSAHAAN_IZIN
	for each row
begin  
   if inserting then 
      if :NEW."ID_PERUSAHAAN_IZIN" is null then 
         select PM_PRUSAHAAN_IZIN_SEQ.nextval into :NEW."ID_PERUSAHAAN_IZIN" from dual; 
      end if; 
   end if; 
end;
