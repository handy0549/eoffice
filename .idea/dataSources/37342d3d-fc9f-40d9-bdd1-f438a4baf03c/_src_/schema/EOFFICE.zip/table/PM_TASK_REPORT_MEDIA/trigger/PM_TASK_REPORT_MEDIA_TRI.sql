create trigger PM_TASK_REPORT_MEDIA_TRI
	before insert
	on PM_TASK_REPORT_MEDIA
	for each row
begin  
   if inserting then 
      if :NEW."ID_MEDIA" is null then 
         select PM_TASK_REPORT_MEDIA_SEQ.nextval into :NEW."ID_MEDIA" from dual; 
      end if; 
   end if; 
end;
