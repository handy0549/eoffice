create trigger PM_PROJECT_LOKASI_TRI
	before insert
	on PM_PROJECT_LOKASI
	for each row
begin  
   if inserting then 
      if :NEW."ID_LOKASI" is null then 
         select PM_PROJECT_LOKASI_SEQ.nextval into :NEW."ID_LOKASI" from dual; 
      end if; 
   end if; 
end;
