create trigger USERS_TRI
	before insert
	on USERS
	for each row
begin  
   if inserting then 
      if :NEW."ID" is null then 
         select USERS_SEQ.nextval into :NEW."ID" from dual; 
      end if; 
   end if; 
end;
