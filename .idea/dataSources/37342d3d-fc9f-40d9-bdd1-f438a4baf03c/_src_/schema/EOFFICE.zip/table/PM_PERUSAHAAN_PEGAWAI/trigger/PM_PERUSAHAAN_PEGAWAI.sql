create trigger PM_PERUSAHAAN_PEGAWAI
	before insert
	on PM_PERUSAHAAN_PEGAWAI
	for each row
begin  
   if inserting then 
      if :NEW."ID_PERUSAHAAN_PEGAWAI" is null then 
         select PM_PRUSAHAAN_PEGAWAI_SEQ.nextval into :NEW."ID_PERUSAHAAN_PEGAWAI" from dual; 
      end if; 
   end if; 
end;
