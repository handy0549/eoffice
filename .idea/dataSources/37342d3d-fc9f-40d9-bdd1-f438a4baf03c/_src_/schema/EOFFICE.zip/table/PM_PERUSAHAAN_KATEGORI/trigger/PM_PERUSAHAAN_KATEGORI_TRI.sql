create trigger PM_PERUSAHAAN_KATEGORI_TRI
	before insert
	on PM_PERUSAHAAN_KATEGORI
	for each row
begin  
   if inserting then 
      if :NEW."ID_PERUSAHAAN_KATEGORI" is null then 
         select PM_PRUSAHAAN_KATEGORI_SEQ.nextval into :NEW."ID_PERUSAHAAN_KATEGORI" from dual; 
      end if; 
   end if; 
end;
