create trigger USERS_MODUL_TRI
	before insert
	on USERS_MODUL
	for each row
begin  
   if inserting then 
      if :NEW."ID_MODUL" is null then 
         select USERS_MODUL_SEQ.nextval into :NEW."ID_MODUL" from dual; 
      end if; 
   end if; 
end;
