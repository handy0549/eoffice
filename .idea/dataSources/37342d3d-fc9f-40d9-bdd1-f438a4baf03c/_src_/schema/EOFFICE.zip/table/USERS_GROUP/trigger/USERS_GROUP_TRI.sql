create trigger USERS_GROUP_TRI
	before insert
	on USERS_GROUP
	for each row
begin  
   if inserting then 
      if :NEW."ID_GROUP" is null then 
         select USERS_GROUP_SEQ.nextval into :NEW."ID_GROUP" from dual; 
      end if; 
   end if; 
end;
