create trigger PM_PROJECT_PAKET
	before insert
	on PM_PROJECT_PAKET
	for each row
begin  
   if inserting then 
      if :NEW."ID_PROJECT_PAKET" is null then 
         select PM_PROJECT_PAKET_SEQ.nextval into :NEW."ID_PROJECT_PAKET" from dual; 
      end if; 
   end if; 
end;
